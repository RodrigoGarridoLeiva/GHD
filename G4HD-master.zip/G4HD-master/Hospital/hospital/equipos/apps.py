from django.apps import AppConfig


class EquiposConfig(AppConfig):
    name = 'equipos'
