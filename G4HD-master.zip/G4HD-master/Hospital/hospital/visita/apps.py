from django.apps import AppConfig


class VisitaConfig(AppConfig):
    name = 'visita'
