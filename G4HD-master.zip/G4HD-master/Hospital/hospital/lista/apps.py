from django.apps import AppConfig


class ListaConfig(AppConfig):
    name = 'lista'
