from django.apps import AppConfig


class DetalleConfig(AppConfig):
    name = 'detalle'
