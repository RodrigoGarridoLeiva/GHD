from django.apps import AppConfig


class RegistrarConfig(AppConfig):
    name = 'registrar'
