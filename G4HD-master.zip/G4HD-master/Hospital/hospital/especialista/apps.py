from django.apps import AppConfig


class EspecialistaConfig(AppConfig):
    name = 'especialista'
