from django import forms
'''from .models import Paciente

class PostForm(forms.ModelForm):
    class Meta:
        model = Paciente
        fields = [
        	'rut',
            'hora',
            'comentario'
        ]'''
