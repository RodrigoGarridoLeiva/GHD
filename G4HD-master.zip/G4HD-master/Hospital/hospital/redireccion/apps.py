from django.apps import AppConfig


class RedireccionConfig(AppConfig):
    name = 'redireccion'
