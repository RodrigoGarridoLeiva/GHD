from django.contrib import admin

from .models import Archivo

admin.site.register(Archivo)
