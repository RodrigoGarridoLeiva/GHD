from django.apps import AppConfig


class HudWebConfig(AppConfig):
    name = 'HUD_web'
